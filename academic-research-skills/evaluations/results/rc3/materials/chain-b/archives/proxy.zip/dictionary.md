Synthetic proxy: different scale and instrument; method B and repeated readings absent. Not validated as equivalent to paired scores.
